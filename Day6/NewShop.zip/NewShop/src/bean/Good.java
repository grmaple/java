package bean;

public class Good
{
	/*
	 * ʵ���࣬��Ʒ��Ϣ
	 */
	public int id;
	public String name;
	public String place;
	public double price;
	public int num;
	public String type;
}
