package bean;

public class User
{
	/*
	 * �û���Ϣ��
	 */
	public int id;
	public String name;
	public String password;
	public double money;
}