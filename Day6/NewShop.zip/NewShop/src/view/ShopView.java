package view;
import impl.ShopImpl;
public class ShopView {
	public static void main(String[] args) {
		//��ʾ��
		ShopImpl sp = new ShopImpl();
		sp.show();
	}
}
